const MongoClient = require("mongodb").MongoClient;
const service = require("./service");

const MONGODB_URI =
    "mongodb+srv://jjolmos:4AMBNrJC7e%40T8cg@cluster0.rbz4c.mongodb.net/dnaDB?authSource=admin&replicaSet=atlas-7ux4ii-shard-0&w=majority&readPreference=primary&appname=MongoDB%20Compass&retryWrites=true&ssl=true";

let cachedDb = null;
async function connectToDatabase() {
    if (cachedDb) {
        return cachedDb;
    }

    const client = await MongoClient.connect(MONGODB_URI);
    const db = await client.db("dnaDB");
    cachedDb = db;
    return db;
}
exports.handler = async (event, context, callback) => {
    let resp = service.hasMutation(event.dna)
    context.callbackWaitsForEmptyEventLoop = false;
    const db = await connectToDatabase();
    let dnaObj = {
        dna: event.dna,
        hasMutation: resp, 
        dnaKey: event.dna.join("")
    }
    const result = await db.collection("dna-collection").insertOne(dnaObj);
    if (!resp) { callback(new Error("The DNA string has no mutations")); }
    const response = {
        statusCode: 200,
        body: resp,
    };
    return response;
};