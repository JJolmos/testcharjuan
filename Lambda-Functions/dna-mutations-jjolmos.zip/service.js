const ArrObjSize = 4;
const hasMutation = (dna) => {
  const lengthtot = dna.length;
  let mutCount = 0;
  if (lengthtot < ArrObjSize) {
      throw Error(`wrong size`);
  }
  for (let i = 0; i < lengthtot; i++) {
    for (let j = 0; j < lengthtot; j++) {
      if (j <= lengthtot - ArrObjSize) {
        const linea = dna[i].substr(j, ArrObjSize);
        mutCount += checkChain(linea);
      }
      if (i <= lengthtot - ArrObjSize) {
        const colm = dna
          .slice(i, i + ArrObjSize)
          .map((bn) => bn.charAt(j))
          .join("");
        mutCount += checkChain(colm);
      }
      if (i <= lengthtot - ArrObjSize && j <= lengthtot - ArrObjSize) {
        let cros = "";
        for (let k = 0; k < ArrObjSize; k++) {
          cros += dna[i + k].charAt(j + k);
        }
        mutCount += checkChain(cros);
      }else{ 
        if(i <= lengthtot - ArrObjSize){       
         let crosx = "";
         for (let k = 0; k < ArrObjSize; k++) {
            crosx += dna[i + k].charAt(j - k);
          }
          mutCount += checkChain(crosx);
        }
      }
      

      
      if (mutCount > 1) { 
        return true; // Mutacion 
      }
    }
  }
  return false;
}

const checkChain = (seq) => {
  if (seq.length !== ArrObjSize){
        throw Error(`wrong size`);
  }
  
 let validateChar = /^[ATCG]+$/;
  if(!validateChar.test(seq)){
      throw Error(`wrong chars`);
  }
  let count = 0;
  for (const sec of seq) {
    count = sec === seq.charAt(0) ? count + 1 : count;
  }
  return count === ArrObjSize ? 1 : 0;
}
exports.hasMutation = hasMutation;