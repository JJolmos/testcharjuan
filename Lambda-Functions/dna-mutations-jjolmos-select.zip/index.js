const MongoClient = require("mongodb").MongoClient;
const MONGODB_URI =
  "mongodb+srv://jjolmos:4AMBNrJC7e%40T8cg@cluster0.rbz4c.mongodb.net/dnaDB?authSource=admin&replicaSet=atlas-7ux4ii-shard-0&w=majority&readPreference=primary&appname=MongoDB%20Compass&retryWrites=true&ssl=true";

let cachedDb = null;
async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const client = await MongoClient.connect(MONGODB_URI);
  const db = await client.db("dnaDB");
  cachedDb = db;
  return db;
}


exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  const db = await connectToDatabase();
  const cadenas = await db.collection("dna-collection").find({}).toArray();
  let count = cadenas.length
  let i=0
  let countM = cadenas.filter ( function ( d ) {
    if(d.hasMutation){i++;}});
  
  let countNM = count-i;
  const response = {
    count_mutations: i,
    count_no_mutation: countNM,
    ratio: i/countNM
  };
  return response;
};